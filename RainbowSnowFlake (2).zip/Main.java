import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

//Generates a snowflake sometimes other times a freakishly cool looking shape.


class Main {
  public static void main(String[] args) {
    World world = new World(500, 500);
    Turtle yertle = new Turtle(world);
    //variable n determines the type of shape
    int n = (int)(Math.random()*10)+3;
    int turnAmount = 45;

    {
      //first loop determins number of shapes
      for (int i = 1; i <= 12; i++) {
        //secound loop makes the shapes and calculates number of sides
        for (int sides = 0; sides <= n; sides++) {
          yertle.turn(360/n);
          yertle.forward(60);

        }
        //changes the color of each shape
        yertle.turn(turnAmount);
        Color yertleColor = new Color((int) (Math.random() * 150), (int) (Math.random() * 150),
        (int) (Math.random() * 150));
        yertle.setColor(yertleColor);
      }
      world.setVisible(true);
    }
  }
}
